<?php $__env->startSection('content'); ?>

    <h1>Listagem dos posts</h1>

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h3><a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a></h3> <br>
        <p><?php echo e($post->body); ?></p>
        <b>Author: <?php echo e($post->user->name); ?></b>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-post')): ?>
            <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Editar</a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-post')): ?>
            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Excluir</button>
            </form>
        <?php endif; ?>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>Nenhum post!</h3>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/site/posts/index.blade.php ENDPATH**/ ?>