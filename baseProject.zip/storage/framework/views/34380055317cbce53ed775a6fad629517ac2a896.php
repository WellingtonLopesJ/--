<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="title">
            Usuário
        </h1>


        <table class="table table-hover">

            <tr>
                <th>Nome</th>
                <th>Tenant</th>
                <th width="150px">Ações</th>
            </tr>

            <?php if( $user ): ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($tenant->name); ?></td>
                    <td>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

        <hr>

        <table class="table table-hover">
           <head><h3>Roles</h3></head>


            <form action="<?php echo e(route('users.give_role')); ?>" method="POST">
                <input type="hidden" name="user_name" value="<?php echo e($user->name); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Atribuir role</button>
            </form>
            <tr>
                <th>Name</th>
                <th>Label</th>
                <th width="150px">Ações</th>
            </tr>

            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($role->name); ?></td>
                    <td><?php echo e($role->label); ?></td>
                    <td>
                        <a href="<?php echo e(route('role.detail', $role->id)); ?>" class="permission btn btn-primary">
                            <i class="fa fa-lock"></i>
                        </a>

                        <form action="<?php echo e(route('users.remove_role')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="90">
                        <p>Nenhum Resultado!</p>
                    </td>
                </tr>
            <?php endif; ?>
        </table>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/panel/users/show.blade.php ENDPATH**/ ?>