<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container" >
        <h1 class="title">
            Tenants list
        </h1>


        <table class="table table-hover">
            <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(route('tenants.create')); ?>" class="btn btn-primary">Criar tenant</a>
            <tr>
                <th>Name</th>
                <th>subdomain</th>
                <th width="150px">Ações</th>
            </tr>

            <?php $__empty_1 = true; $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($tenant->name); ?></td>
                    <td><?php echo e($tenant->subdomain); ?></td>
                    <td>
                        <a href="<?php echo e(route('tenants.show', $tenant->id)); ?>" class="permission btn btn-primary">
                            <i class="fas fa-users"></i>
                        </a>

                        <form action="<?php echo e(route('tenants.destroy', $tenant->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="90">
                        <p>Nenhum Resultado!</p>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/admin/tenants/index.blade.php ENDPATH**/ ?>