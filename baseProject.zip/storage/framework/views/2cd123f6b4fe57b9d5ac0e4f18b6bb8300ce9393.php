<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>AdminController index</p>
    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary">Roles</a>
    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-primary">Permissions</a>
    <a href="<?php echo e(route('tenants.index')); ?>" class="btn btn-primary">Tenants</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/admin/index.blade.php ENDPATH**/ ?>